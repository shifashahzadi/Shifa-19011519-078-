package com.webservice.patient.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "patient")
public class Patient {
	
	@Id
	@GeneratedValue
	@Column(name = "patientid")
	private int PATIENT_ID;
	
	@Column(name = "patient_name")
	private String PATIENT_NAME;
	
	@Column(name = "patient_bloodgroup")
	private String PATIENT_BLOODGROUP;
	
	@Column(name = "patient_disease")
	private String PATIENT_DISEASE;
	
	@Column(name = "patient_medications")
	private String PATIENT_MEDICATIONS;
	
	@Column(name = "patient_remarks")
	private String PATIENT_REMARKS;
	


public Patient() {
	
}

public Patient(int pATIENT_ID, String pATIENT_NAME, String pATIENT_BLOODGROUP, String pATIENT_DISEASE, String pATIENT_MEDICATIONS, String pATIENT_REMARKS) {
	super();
PATIENT_ID = pATIENT_ID;
PATIENT_NAME = pATIENT_NAME;
PATIENT_BLOODGROUP = pATIENT_BLOODGROUP;
PATIENT_DISEASE = pATIENT_DISEASE;
PATIENT_MEDICATIONS = pATIENT_MEDICATIONS;
PATIENT_REMARKS=pATIENT_REMARKS;
}

public int getPATIENT_ID() {
	return PATIENT_ID;
}

public void setPATIENT_ID(int pATIENT_ID) {
	PATIENT_ID = pATIENT_ID;
}

public String getPATIENT_NAME() {
	return PATIENT_NAME;
}

public void setPATIENT_NAME(String pATIENT_NAME) {
	PATIENT_NAME = pATIENT_NAME;
}

public String getPATIENT_BLOODGROUP() {
	return PATIENT_BLOODGROUP;
}

public void setPATIENT_BLOODGROUP(String pATIENT_BLOODGROUP) {
	PATIENT_BLOODGROUP = pATIENT_BLOODGROUP;
}

public String getPATIENT_DISEASE() {
	return PATIENT_DISEASE;
}

public void setPATIENT_DISEASE(String pATIENT_DISEASE) {
	PATIENT_DISEASE = pATIENT_DISEASE;
}

public String getPATIENT_MEDICATIONS() {
	return PATIENT_MEDICATIONS;
}

public void setPATIENT_MEDICATIONS(String pATIENT_MEDICATIONS) {
	PATIENT_MEDICATIONS = pATIENT_MEDICATIONS;
}

public String getPATIENT_REMARKS() {
	return PATIENT_REMARKS;
}

public void setPATIENT_REMARKS(String pATIENT_REMARKS) {
	PATIENT_REMARKS = pATIENT_REMARKS;
}
}
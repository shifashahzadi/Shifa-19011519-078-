package com.webservice.patient.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webservice.patient.entity.Patient;
import com.webservice.patient.repository.PatientRepository;


@Service
public class PatientService {
	
	@Autowired
	private PatientRepository patientRepository;
	
	public Patient saveOne(Patient patient) {
		return patientRepository.save(patient);
	}
	
	public List<Patient> saveMany(List<Patient> patients) {
		return patientRepository.saveAll(patients);
	}
	
	public List<Patient> getAll() {
		return patientRepository.findAll();
	}
	
	public Patient getOne(int id) {
		return patientRepository.findById(id).orElse(null);
	}
	public void deletePatient(int id) {
		patientRepository.deleteById(id); 
	}
	public Patient updatePatient(Patient patient) {
		Patient existingPatient = patientRepository.findById(patient.getPATIENT_ID()).orElse(null);
		existingPatient.setPATIENT_NAME(patient.getPATIENT_NAME());
		existingPatient.setPATIENT_BLOODGROUP(patient.getPATIENT_BLOODGROUP());
		existingPatient.setPATIENT_DISEASE(patient.getPATIENT_DISEASE());
		existingPatient.setPATIENT_MEDICATIONS(patient.getPATIENT_MEDICATIONS());
		existingPatient.setPATIENT_REMARKS(patient.getPATIENT_REMARKS());
		return patientRepository.save(existingPatient);
	}


}

package com.webservice.patient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebService1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebService1Application.class, args);
	}

}
